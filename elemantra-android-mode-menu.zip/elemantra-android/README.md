# ELEMANTRA – Android app (for Codemagic)

A native Android project that runs your game **unchanged**. The original HTML file is in
`app/src/main/assets/www/index.html` (byte-identical to the file you uploaded). The app hosts it in a
full-screen WebView, so every screen, animation, sound and 3D scene is rendered by the same
Chromium engine as in a browser.

## Build it on Codemagic

1. Create a **private** Git repo (GitHub, GitLab or Bitbucket) and push the *contents* of this
   folder to it (`codemagic.yaml` must be at the repo root). The HTML is ~31 MB, which is fine for Git.
2. In Codemagic: **Add application** -> pick the repo -> choose **codemagic.yaml** as the configuration.
3. Start workflow **android-test-apk**. When it finishes, download `app-debug.apk` from the
   build artifacts and install it on a phone. Needs no signing setup.
4. For Google Play use **android-release**:
   - Codemagic > Teams > Code signing identities > Android keystores: upload (or generate) a keystore and
     set its **Reference name** to `elemantra_keystore` (or edit that name in `codemagic.yaml`).
   - Run the workflow; it produces a signed `.apk` and a `.aab` (upload the `.aab` to Play).

## Firebase

The app is set up for the Firebase project app **ELEMANTRA**, package name `com.elemantra.game`
(`applicationId` in `app/build.gradle.kts` matches it).

1. Firebase console > Project settings > your Android app > download **google-services.json**.
2. Put it at `app/google-services.json` and push it to the repo.
3. Build. Firebase Analytics turns on automatically once that file exists; without it the app builds
   and runs normally, just without Firebase.

For features that check your app's signature (Google Sign-In, App Check / Play Integrity) add the
SHA-1 and SHA-256 of your **release keystore** under "Add fingerprint" in Firebase. Codemagic shows
them on the keystore page. Test (debug) builds are signed with a different key each time, so do not use them for that.

## How it works

| Piece | What it does |
|---|---|
| `assets/www/index.html` | Your game, untouched. |
| `MainActivity.kt` | Full-screen WebView, landscape, immersive mode, keeps the screen on, serves the HTML from the APK. |
| `tools/vendor_web_deps.py` | Runs on Codemagic before the build. Downloads three.js, the Tailwind runtime and Google Fonts (Cinzel/Inter) that your page loads from CDNs into `assets/vendor`, so the game also runs **offline**. If a download fails, the app falls back to the CDN when online (`--strict` in the release workflow makes the build fail instead). |
| `tools/ensure_gradle_wrapper.sh` | Generates `gradlew` on the build machine. |

Native behaviour: locked to landscape, immersive full screen, screen stays awake, music autoplay
allowed, system font size ignored (so text matches your design), back button needs a double press to exit,
camera-notch area is letterboxed the way a browser does it.

## Customising

- **Package name / version:** `app/build.gradle.kts` (`applicationId`, `versionName`). `versionCode` comes from
  the Codemagic build number automatically.
- **Update the game:** replace `app/src/main/assets/www/index.html` and push.
- **Icon:** `app/src/main/res/mipmap-*` and `drawable-nodpi` (generated from your loading-screen art).
  `store/play_store_icon_512.png` is ready for the Play listing.
- **Target API:** `targetSdk = 35`. If Google Play asks for a newer level, raise `compileSdk`/`targetSdk`
  (and the Android Gradle Plugin version in the root `build.gradle.kts`).

## Troubleshooting

- Debug builds allow WebView debugging: connect the phone and open `chrome://inspect` on a PC.
- `adb logcat -s Elemantra` shows page console output and whether offline libraries were bundled
  ("Offline libraries bundled: N").
- If the `instance_type: linux_x2` line is rejected, delete it (Codemagic then uses its default machine).
- The page itself needs a phone with an up-to-date **Android System WebView** (Android 7+; auto-updated by Google Play).
